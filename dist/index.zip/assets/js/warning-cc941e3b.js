var warning = function() {
};
var warning_1 = warning;
export { warning_1 as w };
