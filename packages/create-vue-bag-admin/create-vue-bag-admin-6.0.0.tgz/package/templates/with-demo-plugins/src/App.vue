<template>
  <HostApp>
    <template #settings>
      <AppSettingsDrawer />
    </template>
  </HostApp>
</template>

<script setup lang="ts">
import { HostApp } from 'vue-bag-admin'
import AppSettingsDrawer from './components/AppSettingsDrawer.vue'
</script>
