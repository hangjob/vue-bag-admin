import { createApp } from 'vue'
import App from './App.vue'
import 'vue-bag-admin/style.css'
import './style.css'
import { createPinia } from 'pinia'
import { setupHttp } from 'vue-bag-admin'
import { createDiscreteApi } from 'naive-ui'
import {
  PermissionAccess,
  bootstrapPlugins,
  createHostI18n,
  createHostRouter,
  registerPermissionDirective,
  useUserStore
} from 'vue-bag-admin'
import { setupBuiltinDictionaries } from './dictionaries'
import { exampleRoutes } from './routes'
import shopPlugin from '@bag/plugin-shop'
import sysSettingPlugin from '@bag/plugin-sys-setting'

const { message } = createDiscreteApi(['message'])

async function setupApp() {
  const app = createApp(App)
  const pinia = createPinia()
  const i18n = createHostI18n()
  const router = createHostRouter({ routes: exampleRoutes })

  app.use(pinia)
  app.use(i18n)
  setupBuiltinDictionaries()
  app.component('PermissionAccess', PermissionAccess)
  registerPermissionDirective(app)

  const userStore = useUserStore()
  setupHttp({
    baseURL: import.meta.env.VITE_API_URL,
    getToken: () => userStore.token,
    onUnauthorized: () => {
      userStore.logout()
      router.replace({ path: '/login', query: { redirect: router.currentRoute.value.fullPath } })
    },
    onForbidden: () => {
      message.warning('当前账号没有访问权限')
      router.replace('/403')
    },
    onServerError: () => {
      message.error('服务异常，请稍后重试')
    },
    resolveError: (payload) => {
      const data = payload as
        | { success?: boolean; code?: string | number; message?: string }
        | undefined
      if (data?.success === false) {
        return {
          code: data.code,
          message: data.message || 'Request failed'
        }
      }
      return null
    }
  })

  // 挂载插件 (包含了路由注册)
  await bootstrapPlugins({
    app,
    router,
    i18n,
    plugins: [sysSettingPlugin, shopPlugin]
  })

  // 等待路由准备好后再挂载应用
  await router.isReady()
  app.mount('#app')
}

setupApp()
